#RPG game final project
import pygame, time, sys, math
from texture import *
from globals import *
from mapengine import *
from NPC import *
from player import *
from meloonatic_gui import *
from UltraColor import *
from monster import *

pygame.init()

FPS = 0

terrain = Map_engine.load_map("testworld.map")

fps_font = pygame.font.Font("C:\\Windows\\Fonts\\Verdana.ttf", 20)

#BACKGROUND
sky = pygame.image.load("tiles\\sky.png")
Sky = pygame.Surface(sky.get_size())
Sky.blit(sky, (0,0))
del sky
####

#LOGO RPG
logo_img_test = pygame.image.load("tiles\\logo.png")
logo_img_test = pygame.transform.scale(logo_img_test, (1280,980))
logo_img = pygame.Surface(logo_img_test.get_size())
logo_img.blit(logo_img_test,(0,0))
del logo_img_test
####

#Fighting Background
fightB = pygame.image.load("tiles\\fightbackground.jpg")
fightB = pygame.transform.scale(fightB, (1280,980))
FightB = pygame.Surface(fightB.get_size())
FightB.blit(fightB,(0,0))
del fightB
####

#BOSS FIGHTING BACKGROUND
bossB = pygame.image.load("tiles\\bossbg.png")
bossB = pygame.transform.scale(bossB, (1280,980))
BossB = pygame.Surface(bossB.get_size())
BossB.blit(bossB,(0,0))
del bossB

#Dialog Box
dialog_background = pygame.image.load("tiles\\dialogbox.png")
dialog_background = pygame.transform.scale(dialog_background,(980,120))
Dialog_background = pygame.Surface(dialog_background.get_size())
Dialog_background.blit(dialog_background, (0,0))
Dialog_background_width, Dialog_background_height = Dialog_background.get_size()
del dialog_background

#Winning screen
winningscreen = pygame.image.load("tiles\\winscreen.png")
winningscreen = pygame.transform.scale(winningscreen, (1280,980))
Winningscreen = pygame.Surface(winningscreen.get_size())
Winningscreen.blit(winningscreen, (0,0))
del winningscreen

#Dead screen / Lose screen
losescreen = pygame.image.load("tiles\\deadscreen.jpg")
losescreen = pygame.transform.scale(losescreen, (1280,980))
Losescreen = pygame.Surface(losescreen.get_size())
Losescreen.blit(losescreen, (0,0))
del losescreen
#######################
########################
#########################

#Monster
Slime_image = pygame.image.load("tiles\\slime.png")
slimeattack = pygame.image.load("tiles\\slimeattack.png")
slimeattack = pygame.transform.scale(slimeattack, (650,650))

Snake_image = pygame.image.load("tiles\\snakepic.png")
snakeattack = pygame.image.load("tiles\\snakeattack.png")
snakeattack = pygame.transform.scale(snakeattack, (200,300))

Littledragon_image = pygame.image.load("tiles\\littledragonpic.png")
littledragonattack = pygame.image.load("tiles\\fireattack.png")
littledragonattack = pygame.transform.scale(littledragonattack, (200,300))



Bigdragon_image = pygame.image.load("tiles\\bigdragonpic.png")
Bigdragon_image = pygame.transform.scale(Bigdragon_image, (500,500))


#Player
PlayerPic = pygame.image.load("tiles\\player\\PlayerPic.png")
PlayerPic = pygame.transform.scale(PlayerPic, (500,600))
Playerslash = pygame.image.load("tiles\\player\\slash1.PNG")
Playerslash = pygame.transform.scale(Playerslash, (500,500))




clock = pygame.time.Clock()

def Statsboxplayer():
    rect = pygame.draw.rect(screen, (Color.Black), (175, 75, 300, 200), 3)
    return rect

def Statsboxmonster():
    rect = pygame.draw.rect(screen, (Color.Black),(775, 75, 300, 200),3)
    return rect

def show_fps():
    fps_overlay = fps_font.render(str(FPS),True, Color.White)
    screen.blit(fps_overlay, (0,0))


def window():
    global screen, screen_width, screen_height, clock
    screen_width, screen_height = 1280, 980
    pygame.display.set_caption("Slimere")
    screen = pygame.display.set_mode((screen_width,screen_height))
    clock = pygame.time.Clock()


def fps():
    global FPS

    FPS = clock.get_fps()
    if FPS > 0:
        Global.deltatime = 1 / FPS
####

#########################   ####  ##### ##### #####  #     #####  ####################################
#########################   #   # #   #   #     #    #     #      ####################################
#########################   ##### #####   #     #    #     #####  ####################################
#########################   #   # #   #   #     #    #     #      ####################################
#########################   ####  #   #   #     #    ##### #####  ####################################


def Playerstats():
        Statsboxplayer()
        screen.blit(Font.Default.render("Name : ",True, Color.White), (180,100))
        screen.blit(Font.Default.render("Lv :", True, Color.White), (330,100))
        screen.blit(Font.Default.render("HP : ",True, Color.White), (180,130))
        screen.blit(Font.Default.render("XP : ",True, Color.White), (180,160))
        screen.blit(Font.Default.render("Potion : ",True, Color.White), (180,190))
        screen.blit(Font.Default.render("Attack : ",True, Color.White), (180,220))
        screen.blit(Font.Default.render(" / ",True, Color.White), (330,160))
        screen.blit(Font.Default.render(" / ",True, Color.White), (330,130))
        screen.blit(Font.Default.render(player.name,True, Color.White), (270,100))
        screen.blit(Font.Default.render(str(player.lv),True, Color.White), (370,100))
        screen.blit(Font.Default.render(str(player.hp),True, Color.White), (270,130))
        screen.blit(Font.Default.render(str(player.maxhp), True, Color.White), (370,130))
        screen.blit(Font.Default.render(str(player.xp),True, Color.White), (270, 160))
        screen.blit(Font.Default.render(str(player.maxxp),True, Color.White), (370, 160))
        screen.blit(Font.Default.render(str(player.pot),True,Color.White), (270,190))
        screen.blit(Font.Default.render(str(player.attack),True,Color.White), (270,220))

def Monsterstats1():
        Statsboxmonster()
        screen.blit(Font.Default.render("Name : ",True, Color.White), (780,100))
        screen.blit(Font.Default.render("HP : ",True, Color.White), (780,130))
        screen.blit(Font.Default.render("XP : ",True, Color.White), (780,160))
        screen.blit(Font.Default.render("Attack : ",True, Color.White), (780,190))
        screen.blit(Font.Default.render(" / ",True, Color.White), (930,130))
        screen.blit(Font.Default.render(slime.name,True, Color.White), (870,100))
        screen.blit(Font.Default.render(str(slime.hp),True, Color.White), (870,130))
        screen.blit(Font.Default.render(str(slime.maxhp), True, Color.White), (970,130))
        screen.blit(Font.Default.render(str(slime.maxxp),True, Color.White), (870, 160))
        screen.blit(Font.Default.render(str(slime.attack),True,Color.White), (870,190))

def Monsterstats2():
        Statsboxmonster()
        screen.blit(Font.Default.render("Name : ",True, Color.White), (780,100))
        screen.blit(Font.Default.render("HP : ",True, Color.White), (780,130))
        screen.blit(Font.Default.render("XP : ",True, Color.White), (780,160))
        screen.blit(Font.Default.render("Attack : ",True, Color.White), (780,190))
        screen.blit(Font.Default.render(" / ",True, Color.White), (930,130))
        screen.blit(Font.Default.render(snake.name,True, Color.White), (870,100))
        screen.blit(Font.Default.render(str(snake.hp),True, Color.White), (870,130))
        screen.blit(Font.Default.render(str(snake.maxhp), True, Color.White), (970,130))
        screen.blit(Font.Default.render(str(snake.maxxp),True, Color.White), (870, 160))
        screen.blit(Font.Default.render(str(snake.attack),True,Color.White), (870,190))

def Monsterstats3():
        Statsboxmonster()
        screen.blit(Font.Default.render("Name : ",True, Color.White), (780,100))
        screen.blit(Font.Default.render("HP : ",True, Color.White), (780,130))
        screen.blit(Font.Default.render("XP : ",True, Color.White), (780,160))
        screen.blit(Font.Default.render("Attack : ",True, Color.White), (780,190))
        screen.blit(Font.Default.render(" / ",True, Color.White), (930,130))
        screen.blit(Font.Default.render(littledragon.name,True, Color.White), (870,100))
        screen.blit(Font.Default.render(str(littledragon.hp),True, Color.White), (870,130))
        screen.blit(Font.Default.render(str(littledragon.maxhp), True, Color.White), (970,130))
        screen.blit(Font.Default.render(str(littledragon.maxxp),True, Color.White), (870, 160))
        screen.blit(Font.Default.render(str(littledragon.attack),True,Color.White), (870,190))

def Monsterstats4():
        Statsboxmonster()
        screen.blit(Font.Default.render("Name : ",True, Color.White), (780,100))
        screen.blit(Font.Default.render("HP : ",True, Color.White), (780,130))
        screen.blit(Font.Default.render("XP : ",True, Color.White), (780,160))
        screen.blit(Font.Default.render("Attack : ",True, Color.White), (780,190))
        screen.blit(Font.Default.render(" / ",True, Color.White), (930,130))
        screen.blit(Font.Default.render(bigdragon.name,True, Color.White), (870,100))
        screen.blit(Font.Default.render(str(bigdragon.hp),True, Color.White), (870,130))
        screen.blit(Font.Default.render(str(bigdragon.maxhp), True, Color.White), (970,130))
        screen.blit(Font.Default.render(str(bigdragon.maxxp),True, Color.White), (870, 160))
        screen.blit(Font.Default.render(str(bigdragon.attack),True,Color.White), (870,190))




window()

#
player = Player("Ryo",150,30,100,1,0)
player_w, player_h = player.width, player.height
player_x = (screen_width / 2 - player_w / 2 - Global.camera_x) / Tiles.size
player_y = (screen_width / 2 - player_h / 2 - Global.camera_y) / Tiles.size


#MUSIC
#pygame.mixer.music.load("")


#SOUND EFFECT
#buttonSound = pygame.mixer.Sound("")


TestDialog = Dialog(text = [("abcdefghjiklk")])
Global.active_dialog = TestDialog


man1 = Male1(name = "Boy", pos = (607,640),
             dialog = Dialog(text = [("Hello world this is amazing")]))


                #name,    pos,    hp,  attack,  xp, lvl
slime = Slime("Slime", (225,315), 70,  10,     40, 1)
snake = Snake("Snake", (220,1900), 150,  15,     60, 3)
littledragon = Littledragon("Littledragon", (1663,336), 300, 30, 80, 5)
bigdragon = Bigdragon("Bigdragon", (1090, 2390), 1000, 70, 200, 10)


#GUI
def Play():
    Global.scene ="game"
    #pygame.mixer.music.play(-1)

def Exit():
    global Rungame
    Rungame = False

def Fight():
    Global.scene = "fight"

Playbutton = Menu.Button(text = "Play", rect = (screen_width /2-100,400,200,100),
                         bg = Color.Gray, fg = Color.White,
                         bgr = Color.CornflowerBlue, tag = ("menu", None))

Playbutton.Command = Play


Exitbutton = Menu.Button(text = "Exit", rect = (screen_width /2-100,503,200,100),
                         bg = Color.Gray, fg = Color.White,
                         bgr = Color.CornflowerBlue, tag = ("menu", None))

Exitbutton.Command = Exit

Quitbutton = Menu.Button(text = "Quit", rect = (screen_width /2-100,803,200,100),
                         bg = Color.Gray, fg = Color.White,
                         bgr = Color.CornflowerBlue, tag = ("lose", None))

Quitbutton.Command = Exit

Winbutton = Menu.Button(text = "Quit", rect = (screen_width /2-100,803,200,100),
                         bg = Color.Gray, fg = Color.White,
                         bgr = Color.CornflowerBlue, tag = ("win", None))

Winbutton.Command = Exit




menuTitle = Menu.Text(text = "Slimere ", color = Color.Black,
                      font = Font.Large)

menuTitle.Left, menuTitle.Top = 520, 50

logo = Menu.Image(bitmap = logo_img, pos = (0,0))
####



Rungame = True

while Rungame == True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Rungame = False

        #Movement for player
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w and not Global.dialog_open:
                Global.camera_move = 1
                player.facing = "faceup"
            elif event.key == pygame.K_s and not Global.dialog_open:
                Global.camera_move = 2
                player.facing = "facedown"
            elif event.key == pygame.K_a and not Global.dialog_open:
                Global.camera_move = 3
                player.facing = "faceleft"
            elif event.key == pygame.K_d and not Global.dialog_open:
                Global.camera_move = 4
                player.facing = "faceright"








            if event.key == pygame.K_RETURN:
                if Global.dialog_open:
                    # HANDLE NEXT PAGE OF OPEN DIALOG
                    if Global.active_dialog.Page < len(Global.active_dialog.Text) - 1:
                        Global.active_dialog.Page += 1
                    else:
                        Global.dialog_open = False
                        Global.active_dialog.Page = 0
                        Global.active_dialog = None

                        #UNPAUSE ANY PAUSED NPC'S
                        for npc in NPC.allNPC:
                            if not npc.Timer.Active:
                                npc.Timer.Start()

                elif Global.combat_open:
                    Global.combat_monsterslime = 1


                else:
                    # IF DIALOG ISNT OPEN
                    for npc in NPC.allNPC:
                        #IS PLAYER IN SPEECH BOUNDSs
                        npc_x = npc.x / Tiles.size
                        npc_y = npc.y / Tiles.size
                        if player_x >= npc_x - 2 and player_x < npc_x + 2 and player_y >= npc_y - 2 and player_y <= npc_y + 2:
                            #PLAYER IS NEXT TO NPC HOWEVER IS PLAYER FACING THEM?
                            if player.facing == "faceup" and npc_y < player_y:
                                npc.facing = "facedown"
                                Global.dialog_open = True
                                Global.active_dialog = npc.Dialog
                                npc.Timer.Pause()
                                npc.walking = False
                            elif player.facing == "facedown" and npc_y > player_y:
                                npc.facing = "faceup"
                                Global.dialog_open = True
                                Global.active_dialog = npc.Dialog
                                npc.Timer.Pause()
                                npc.walking = False
                            elif player.facing == "faceleft" and npc_x < player_x:
                                npc.facing = "faceright"
                                Global.dialog_open = True
                                Global.active_dialog = npc.Dialog
                                npc.Timer.Pause()
                                npc.walking = False
                            elif player.facing == "faceright" and npc_x > player_x:
                                npc.facing = "faceleft"
                                Global.dialog_open = True
                                Global.active_dialog = npc.Dialog
                                npc.Timer.Pause()
                                npc.walking = False

                    #Monster slime
                    for monster in Monster.allMonster:
                        slime_x = slime.x / Tiles.size
                        slime_y = slime.y / Tiles.size
                        if player_x >= slime_x - 2 and player_x < slime_x + 2 and player_y >= slime_y - 2 and player_y <= slime_y + 2:
                        #PLAYER IS NEXT TO NPC HOWEVER IS PLAYER FACING THEM?
                            if player.facing == "faceup" and slime_y < player_y:
                                Global.combat_open = 1


                            elif player.facing == "facedown" and slime_y > player_y:
                                Global.combat_open = 1



                            elif player.facing == "faceleft" and slime_x < player_x:
                                Global.combat_open = 1


                            elif player.facing == "faceright" and slime_x > player_x:
                                Global.combat_open = 1

                    #Monster snake
                    for monster in Monster.allMonster:
                        snake_x = snake.x / Tiles.size
                        snake_y = snake.y / Tiles.size
                        if player_x >= snake_x - 2 and player_x < snake_x + 2 and player_y >= snake_y - 2 and player_y <= snake_y + 2:
                        #PLAYER IS NEXT TO NPC HOWEVER IS PLAYER FACING THEM?
                            if player.facing == "faceup" and snake_y < player_y:
                                Global.combat_open = 2


                            elif player.facing == "facedown" and snake_y > player_y:
                                Global.combat_open = 2


                            elif player.facing == "faceleft" and snake_x < player_x:
                                Global.combat_open = 2


                            elif player.facing == "faceright" and snake_x > player_x:
                                Global.combat_open = 2

                    #Monster littledragon
                    for monster in Monster.allMonster:
                        littledragon_x = littledragon.x / Tiles.size
                        littledragon_y = littledragon.y / Tiles.size
                        if player_x >= littledragon_x - 2 and player_x < littledragon_x + 2 and player_y >= littledragon_y - 2 and player_y <= littledragon_y + 2:
                        #PLAYER IS NEXT TO NPC HOWEVER IS PLAYER FACING THEM?
                            if player.facing == "faceup" and littledragon_y < player_y:
                                Global.combat_open = 4


                            elif player.facing == "facedown" and littledragon_y > player_y:
                                Global.combat_open = 4


                            elif player.facing == "faceleft" and littledragon_x < player_x:
                                Global.combat_open = 4


                            elif player.facing == "faceright" and littledragon_x > player_x:
                                Global.combat_open = 4

                    #Monster Bigdragon (BOSS)
                    for monster in Monster.allMonster:
                        bigdragon_x = bigdragon.x / Tiles.size
                        bigdragon_y = bigdragon.y / Tiles.size
                        if player_x >= bigdragon_x - 2 and player_x < bigdragon_x + 2 and player_y >= bigdragon_y - 2 and player_y <= bigdragon_y + 2:
                        #PLAYER IS NEXT TO NPC HOWEVER IS PLAYER FACING THEM?
                            if player.facing == "faceup" and bigdragon_y < player_y:
                                Global.combat_open = 5


                            elif player.facing == "facedown" and bigdragon_y > player_y:
                                Global.combat_open = 5


                            elif player.facing == "faceleft" and bigdragon_x < player_x:
                                Global.combat_open = 5


                            elif player.facing == "faceright" and bigdragon_x > player_x:
                                Global.combat_open = 5


        elif event.type == pygame.KEYUP:
            Global.camera_move = 0

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:   #LEFT CLICK

                #HANDLE BUTTON CLICK EVENTS
                for btn in Menu.Button.All:
                    if btn.Tag[0] == Global.scene and btn.Rolling:
                        if btn.Command != None:
                            btn.Command()   #DO BUTTON EVENT
                        #buttonSound.play()
                        btn.Rolling = False
                        break


        #COLLISION
    #     collision = pygame.sprite.spritecollide(player, monster, False)
    #
    # # if collision and not Combat_open:
    # #     if collision[0].name != "Bigdragon":
    #     combat_open = True
    #
    #     if combat_open:
    #         screen.blit(FightB, (0,0))
    #
    #
    #         if collision[0].name == "Slime":
    #             screen.blit(Slime_image, (700,400))




####



    #RENDER SCENE
    if Global.scene == "game":

        #LOGIC for the movement
        if Global.camera_move == 1:
            if not Tiles.blockedAt((round(player_x), math.floor(player_y))):
                Global.camera_y += 300 * Global.deltatime
        elif Global.camera_move == 2:
            if not Tiles.blockedAt((round(player_x), math.ceil(player_y))):
                Global.camera_y -= 300 * Global.deltatime
        elif Global.camera_move == 3:
            if not Tiles.blockedAt((math.floor(player_x), round(player_y))):
                Global.camera_x += 300 * Global.deltatime
        elif Global.camera_move == 4:
            if not Tiles.blockedAt((math.ceil(player_x), round(player_y))):
                Global.camera_x -= 300 * Global.deltatime
        player_x = (screen_width / 2 - player_w / 2 - Global.camera_x) / Tiles.size
        player_y = (screen_width / 2 - player_h / 2 - Global.camera_y) / Tiles.size
####


        #RENDER
        screen.blit(Sky,(0,0))
        screen.blit(terrain, (Global.camera_x, Global.camera_y))
        # playerSprite.draw(screen)
        for npc in NPC.allNPC:
            npc.Render(screen)
            npc.Timer.Pause()
            npc.walking = False

        for monster in Monster.allMonster:
            monster.Render(screen)
            monster.Timer.Pause()
            monster.walking = False

        # for monster in Monster.allmonsters:
        #     monster.Render(screen)
        player.render(screen, (607,607))

        if Global.dialog_open:
            screen.blit(Dialog_background, (screen_width / 2 - Dialog_background_width / 2, screen_height - Dialog_background_height - 2))

            #DRAW DIALOG TEXT
            if Global.active_dialog != None:
                lines = Global.active_dialog.Text[Global.active_dialog.Page]


                    #Draw Text to screen
                screen.blit(Font.Default.render("How are you traveller? My name is Bob, There are monsters around these forest.", True, Color.RosyBrown), (180, (880)))


####SLIME


        if Global.combat_open == 1:
            #Global.combat_monsterslime = 1
            screen.blit(FightB, (0,0))
            screen.blit(PlayerPic, (100,250))
            screen.blit(Slime_image, (800,350))

            #Stats blit
            Playerstats()
            Monsterstats1()
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_f:
                        slime.hp -= player.attack
                        #Animate Hero attack
                        screen.blit(Playerslash ,(700,250))
                        screen.blit(Font.Default.render(("You deal {} Damage".format(player.attack)),True,Color.White), (400,850))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)


                        player.hp -= slime.attack
                        #Animate Monster attack
                        screen.blit(slimeattack, (0,200))
                        screen.blit(Font.Default.render(("Slime deal {} Damage".format(slime.attack)),True,Color.White), (400,900))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)
                        Playerstats()
                        Monsterstats1()

                        if slime.hp <= 0:
                            Global.combat_open = 0
                            slime.hp = slime.maxhp
                            player.xp += slime.maxxp
                            if player.xp > player.maxxp:
                                player.xp = 0
                                player.maxxp += 50
                                player.maxhp += 50
                                player.hp = player.maxhp
                                player.lv += 1
                                player.pot += 1
                                player.attack += 5
                            if player.lv == 10:
                                player.maxhp = 1000
                                player.hp = player.maxhp
                                player.attack = 100
                                player.maxxp = player.xp
                        elif player.hp <= 0:
                            Global.scene = "lose"
                    if event.key == pygame.K_h:
                        if player.pot == 0:
                            pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                            screen.blit(Font.Default.render("You dont have enough pot",True,Color.White), (400,850))
                            pygame.display.flip()
                            pygame.time.wait(500)
                        if player.pot >= 1:
                            if player.hp == player.maxhp:
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are already max hp",True,Color.White), (400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)
                            else:
                                player.hp = player.maxhp
                                player.pot -= 1
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are healed!",True,Color.White), (400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)


#####SNAKE


        elif Global.combat_open == 2:
            #Global.combat_monstersnake = 1
            screen.blit(FightB, (0,0))
            screen.blit(PlayerPic, (100,250))
            screen.blit(Snake_image, (800,350))

            #Stats blit
            Playerstats()
            Monsterstats2()
            attack = 0
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_f:
                        snake.hp -= player.attack
                        #Animate Hero attack
                        screen.blit(Playerslash ,(700,250))
                        screen.blit(Font.Default.render(("You deal {} Damage".format(player.attack)),True,Color.White), (400,850))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)


                        player.hp -= snake.attack
                        #Animate Monster attack
                        screen.blit(snakeattack, (200,400))
                        screen.blit(Font.Default.render(("Snake deal {} Damage".format(snake.attack)),True,Color.White), (400,900))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)
                        Playerstats()
                        Monsterstats2()


                        if snake.hp <= 0:
                            Global.combat_open = 0
                            snake.hp = snake.maxhp
                            player.xp += snake.maxxp
                            if player.xp > player.maxxp:
                                player.xp = 0
                                player.maxxp += 50
                                player.maxhp += 50
                                player.hp = player.maxhp
                                player.lv += 1
                                player.pot += 1
                                player.attack += 5
                            if player.lv == 10:
                                player.maxhp = 1000
                                player.hp = player.maxhp
                                player.attack = 100
                                player.maxxp = player.xp
                        elif player.hp <= 0:
                            Global.scene = "lose"
                    if event.key == pygame.K_h:
                        if player.pot == 0:
                            pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                            screen.blit(Font.Default.render("You dont have enough pot",True,Color.White), (400,850))
                            pygame.display.flip()
                            pygame.time.wait(500)
                        if player.pot >= 1:
                            if player.hp == player.maxhp:
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are already max hp",True,Color.White), (400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)
                            else:
                                player.hp = player.maxhp
                                player.pot -= 1
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are healed!",True,Color.White),(400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)


####Littledragon


        elif Global.combat_open == 4:
            screen.blit(FightB, (0,0))
            screen.blit(PlayerPic, (100,250))
            screen.blit(Littledragon_image, (800,350))

            #Stats blit
            Playerstats()
            Monsterstats3()
            attack = 0
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_f:
                        littledragon.hp -= player.attack
                        #Animate Hero attack
                        screen.blit(Playerslash ,(600,300))
                        screen.blit(Font.Default.render(("You deal {} Damage".format(player.attack)),True,Color.White), (400,850))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)


                        player.hp -= littledragon.attack
                        #Animate Monster attack
                        screen.blit(littledragonattack, (200,350))
                        screen.blit(Font.Default.render(("Little dragon deal {} Damage".format(littledragon.attack)),True,Color.White), (400,900))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)
                        Playerstats()
                        Monsterstats2()


                        if littledragon.hp <= 0:
                            Global.combat_open = 0
                            littledragon.hp = littledragon.maxhp
                            player.xp += littledragon.maxxp
                            if player.xp > player.maxxp:
                                player.xp = 0
                                player.maxxp += 50
                                player.maxhp += 50
                                player.hp = player.maxhp
                                player.lv += 1
                                player.pot += 1
                                player.attack += 5
                            if player.lv == 10:
                                player.maxhp = 1000
                                player.hp = player.maxhp
                                player.attack = 100
                                player.maxxp = player.xp
                        elif player.hp <= 0:
                            Global.scene = "lose"
                    if event.key == pygame.K_h:
                        if player.pot == 0:
                            pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                            screen.blit(Font.Default.render("You dont have enough pot",True,Color.White), (400,850))
                            pygame.display.flip()
                            pygame.time.wait(500)
                        if player.pot >= 1:
                            if player.hp == player.maxhp:
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are already max hp",True,Color.White), (400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)
                            else:
                                player.hp = player.maxhp
                                player.pot -= 1
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are healed!",True,Color.White),(400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)

        elif Global.combat_open == 5:
            screen.blit(BossB, (0,0))
            screen.blit(PlayerPic, (100,250))
            screen.blit(Bigdragon_image, (780,300))

            #Stats blit
            Playerstats()
            Monsterstats4()
            attack = 0
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_f:
                        bigdragon.hp -= player.attack
                        #Animate Hero attack
                        screen.blit(Playerslash ,(600,300))
                        screen.blit(Font.Default.render(("You deal {} Damage".format(player.attack)),True,Color.White), (400,850))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)


                        player.hp -= bigdragon.attack
                        #Animate Monster attack
                        screen.blit(littledragonattack, (200,350))
                        screen.blit(Font.Default.render(("Big dragon(Boss) deal {} Damage".format(bigdragon.attack)),True,Color.White), (400,900))
                        pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                        pygame.display.flip()
                        pygame.time.wait(750)
                        Playerstats()
                        Monsterstats2()


                        if bigdragon.hp <= 0:
                            Global.scene = "win"
                            bigdragon.hp = bigdragon.maxhp
                            player.xp += bigdragon.maxxp
                            if player.xp > player.maxxp:
                                player.xp = 0
                                player.maxxp += 50
                                player.maxhp += 50
                                player.hp = player.maxhp
                                player.lv += 1
                                player.pot += 1
                                player.attack += 5
                            if player.lv == 10:
                                player.maxhp = 1000
                                player.hp = player.maxhp
                                player.attack = 100
                                player.maxxp = player.xp
                        elif player.hp <= 0:
                            Global.scene = "lose"
                    if event.key == pygame.K_h:
                        if player.pot == 0:
                            pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                            screen.blit(Font.Default.render("You dont have enough pot",True,Color.White), (400,850))
                            pygame.display.flip()
                            pygame.time.wait(500)
                        if player.pot >= 1:
                            if player.hp == player.maxhp:
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are already max hp",True,Color.White), (400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)
                            else:
                                player.hp = player.maxhp
                                player.pot -= 1
                                pygame.draw.rect(screen, (Color.Black), (355, 805, 500, 150), 3)
                                screen.blit(Font.Default.render("You are healed!",True,Color.White),(400,850))
                                pygame.display.flip()
                                pygame.time.wait(500)
        # for t in Tiles.Blocked:
        #     pygame.draw.rect(screen, Color.Red,(t[0] * Tiles.size + Global.camera_x, t[1] * Tiles.size + Global.camera_y, Tiles.size, Tiles.size), 2)




    elif Global.scene == "menu":
        screen.fill(Color.Fog)
        logo.Render(screen)
        menuTitle.Render(screen)
        pygame.draw.rect(screen, (Color.Black), (355, 805, 700, 150), 3)
        screen.blit(Font.Default.render("Control Tutorial : ",True,Color.White),(400,820))
        screen.blit(Font.Default.render("In battle, press F to attack, press H to heal with potion",True,Color.White),(400,850))
        screen.blit(Font.Default.render("Press Enter to interact with monster or NPC",True,Color.White),(400,880))
        screen.blit(Font.Default.render("Use W,A,S,D to move ",True,Color.White),(400,910))
        for btn in Menu.Button.All:
            if btn.Tag[0] == "menu":
                btn.Render(screen)

    elif Global.scene == "lose":
        screen.fill(Color.Fog)
        screen.blit(Losescreen,(0,0))
        for btn in Menu.Button.All:
            if btn.Tag[0] == "lose":
                btn.Render(screen)

    elif Global.scene == "win":
        screen.fill(Color.Fog)
        screen.blit(Winningscreen, (0,0))
        for btn in Menu.Button.All:
            if btn.Tag[0] == "win":
                btn.Render(screen)



    fps()
    clock.tick()
    pygame.display.update()
    show_fps()


pygame.quit()
sys.exit()


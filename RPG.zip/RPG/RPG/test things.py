words = "This is random text"
words2 = words.split()
print(words2)

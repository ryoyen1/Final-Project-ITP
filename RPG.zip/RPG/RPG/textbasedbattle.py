import random, sys

class Stats:
    def __init__(self,name,hp,maxhp,xp,maxxp,lv,attack,potion):
        self.name = name
        self.hp = hp
        self.maxhp = maxhp
        self.xp = xp
        self.maxxp = maxxp
        self.lv = lv
        self.attack = attack
        self.potion = potion

class Monster:
    def __init__(self,name,hp,maxhp,xp,lv,attack):
        self.name = name
        self.hp = hp
        self.maxhp = maxhp
        self.xp = xp
        self.lv = lv
        self.attack = attack
#LIST OF MONSTER AND HEROES
character = Stats("Hero", 100, 100, 1,100, 1, 10,0)

Slime = Monster("Slime", 15, 15, 10, 1, 7)
Snake = Monster("Snake", 40, 40, 30, 4, 12)
Fishman = Monster("Fishman", 75, 75, 70, 7, 20)
Dragonlittle = Monster("Dragon kid", 120, 120, 110, 12, 40)
Boss = Monster("Big dragon", 1500, 1500, 400, "?", 100)


##Function to show
def viewstartmenu():
    print("1. Play the game")
    print("2. Exit the game")

def stats():
    print(" Name :",character.name)
    print(" HP : ", character.hp,"/", character.maxhp)
    print(" XP : ", character.xp,"/", character.maxxp )
    print(" Lv : ", character.lv)
    print(" Potion : ", character.potion)

def monsterlist():
    print("1. Slime")
    print("2. Snake")
    print("3. Fishman")
    print("4. L. Dragon")
    print("5. Boss ")



##Fight Function
def menu():
    viewstartmenu()
    number = int(input("Pick one: "))
    if number == 1:
        play()
    if number == 2:
        sys.exit()

def play():
    print("Input a name :")
    nameinput = input(" : ")
    character.name = nameinput
    game()

def game():
    stats()
    choice = input("Fight now (Y/N)\n").upper()
    if choice == "Y":
        monsters()
    if choice == 'N':
        print("Why did u say no?\n")
        game()

def monsters():
    monsterlist()
    choice = int(input("Which monster would you like to fight? :"))
    if choice == 1:
        battle("Slime")
    if choice == 2:
        battle("Snake")
    if choice == 3:
        battle("Fishman")
    if choice == 4:
        battle("Dragon kid")
    if choice == 5:
        battle("Big dragon")

def battle(name):
    if Slime.name == "Slime":
        a = Slime.name
        b = Slime.hp
        c = Slime.xp
        d = Slime.attack
        e = Slime.lv
        fight()
    elif Snake.name == "Snake":
        a = Snake.name
        b = Snake.hp
        c = Snake.xp
        d = Snake.attack
        e = Snake.lv
        fight()
    elif Fishman.name == "Fishman":
        a = Fishman.name
        b = Fishman.hp
        c = Fishman.xp
        d = Fishman.attack
        e = Fishman.lv
        fight()
    elif Dragonlittle.name == "Dragonlittle":
        a = Dragonlittle.name
        b = Dragonlittle.hp
        c = Dragonlittle.xp
        d = Dragonlittle.attack
        e = Dragonlittle.lv
        fight()
    elif Boss.name == 'Boss':
        a = Boss.name
        b = Boss.hp
        c = Boss.xp
        d = Boss.attack
        e = Boss.lv
        fight()

def fight():
    print("")









menu()


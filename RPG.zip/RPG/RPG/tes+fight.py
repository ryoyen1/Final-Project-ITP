import random,sys,os
from os import system, name

class Mahluk:
    def __init__(self,name,hp,attack,xp,lv):
        self.name = name
        self.maxhp = hp
        self.hp = self.maxhp
        self.attack = attack
        self.maxxp = xp
        self.xp = 0
        self.lv = lv
        self.maxlv = 1900
        self.pot = 0

char = Mahluk('ERISKUN',100,30,100,1)
ant = Mahluk('Ant',90,10,40,1)
snake = Mahluk('Snake',120,15,60,2)
jellyfish = Mahluk('Jellyfish',90,40,100,4)
crab = Mahluk('Crab',200,25,130,5)
deadwood = Mahluk('Deadwood',400,40,200,7)
skeleton = Mahluk('Skeleton',290,60,235,8)
dragon = Mahluk('Dragon',500,70,380,9)
greatdragon = Mahluk('GreatDragon',650,85,450,10)
wyvern = Mahluk('Wyvern(boss)',146000,27600,0,999)





def play():
    print("Let's Play")
    print("1.New game")
    print("2.Exit")
    choice = int(input("choose : "))
    if choice == 1:
        start()
    if choice == 2:
        sys.exit()


def start():
    #os.system('clear')
    print("Hello Kid, Tell Me Your Name  ")
    a = input(": ")
    char.name = a
    menu()


def menu():
    #os.system('clear')tem('clear')
    print ("Nickname : ", char.name,"\nlv:",char.lv)
    print("HP : ",char.hp,"/",char.maxhp)
    print("Attack :", char.attack)
    print("Xp :", char.xp,"/",char.maxxp)
    print("Pot :",char.pot)
    print("\nfight now? Y/N")
    choice = input(": ").upper()
    if choice == "Y":
        enemy()
    elif choice == "N":
        menu()
    else :
        menu()

def enemy():
    choose = int(input("1.Ant\n2.Snake\n3.jellyfish\n4.crab\n5.deadwood\n6.skeleton\n7.dragon\n8.greatdragon\n9.wyvern(BOSS)"))
    if choose == 1:
        fight('ant')
    elif choose == 2:
        fight('snake')
    elif choose ==3:
        fight('jellyfish')
    elif choose == 4:
        fight('crab')
    elif choose == 5:
        fight('deadwood')
    elif choose == 6:
        fight('skeleton')
    elif choose == 7:
        fight('dragon')
    elif choose == 8:
        fight('greatdragon')
    elif choose == 9:
        fight('wyvern')
    else :
        enemy()



def fight(name):


    if name == 'ant':
        a = ant.name
        b = ant.maxhp
        d = ant.lv
        e = ant.attack
        f = ant.maxxp
    elif name == 'snake':
        a = snake.name
        b = snake.maxhp
        d = snake.lv
        e = snake.attack
        f = snake.maxxp
    elif name == 'jellyfish':
        a = jellyfish.name
        b= jellyfish.maxhp
        d = jellyfish.lv
        e = jellyfish.attack
        f = jellyfish.maxxp

    elif name == 'crab':
        a = crab.name
        b= crab.maxhp
        d = crab.lv
        e = crab.attack
        f = crab.maxxp
    elif name == 'deadwood':
        a = deadwood.name
        b = deadwood.maxhp
        d = deadwood.lv
        e = deadwood.attack
        f = deadwood.maxxp
    elif name == 'skeleton':
        a = skeleton.name
        b= skeleton.maxhp
        d = snake.lv
        e = skeleton.attack
        f = skeleton.maxxp
    elif name == 'dragon':
        a = dragon.name
        b= dragon.maxhp
        d = dragon.lv
        e = dragon.attack
        f = dragon.maxxp
    elif name == 'greatdragon':
        a = greatdragon.name
        b= greatdragon.maxhp
        d = greatdragon.lv
        e = greatdragon.attack
        f = greatdragon.maxxp
    elif name == 'wyvern':
        a = wyvern.name
        b = wyvern.maxhp
        d = wyvern.lv
        e = wyvern.attack
        f = wyvern.maxxp
    while True:
        critical = random.randint(0,3)
        if critical == 2:
            att = char.attack * 2
        else:
            att = random.randint(char.attack/2,char.attack )
        c = random.randint(int(e / 2), e)

        print(char.name,"lv:",char.lv, "                 ",a,"lvl:",d)
        print("HP:",char.hp,"/",char.maxhp,"               HP:",b)
        print("Attack:", char.attack,"       VS         Attack:",c)
        print("Xp:", char.xp,"/",char.maxxp)
        print("___________________________________________________________")
        action = input('1.Attack\n2.Drink Pot\n3.RunAway')

        if action == '1':
            #os.system('clear')
            b -= att
            if critical == 2:
                print("\n\nCRITICAL HIT!!")
                print("YOU DEAL",att,"DAMAGE!!")
            else:
                print("\n\nYOU DEAL",att,"DAMAGE!!")
            if b <= 0:
                print("\n\nYOU WIN!!\n\n")
                char.xp += f
                if char.xp > char.maxxp and char.xp < 1900:
                    char.maxhp += 60
                    char.hp = char.maxhp
                    char.attack += 30
                    xp_current = char.xp - char.maxxp
                    char.xp = xp_current
                    char.maxxp += 200
                    char.lv += 1
                    char.pot +=1
                elif char.xp >= char.maxlv and char.xp >= 1900:
                    char.maxhp +=200000
                    char.hp = char.maxhp
                    char.attack +=39000
                    char.lv = str("MAX LEVEL")
                    print("\nCONGRATULATION! YOU HAVE REACHED MAX LEVEL!!")
                menu()




            elif b > 0:
                char.hp -= c
            print(a,"DEALS",c,"DAMAGE!!\n\n")
            if char.hp <=0:
                print("\n\nYOU DIED\n\n")
                char.hp = char.maxhp
                play()
        elif action == '2':
            if char.pot == 0:
                print("\n\nYou Don't Have Any Pots\n\n")
            elif char.pot > 0:
                char.hp = char.maxhp
                char.pot -= 1
                print("\nYou Drank a Potion\n\n")
        elif action == '3':
            print("\n\nRUNNING AWAY IS FOR NUB\n\n")






play()


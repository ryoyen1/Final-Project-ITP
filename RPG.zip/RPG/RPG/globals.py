class Global:

    camera_x = 0
    camera_y = 0
    camera_move = 0
    scene = "menu"
    deltatime = 0

    dialog_open = True
    active_dialog = None

    combat_open = 0
    combat_monsterslime = 0
    combat_monstersnake = 0

import pygame, random
from timer import *
from globals import *
from texture import *

pygame.init()

def get_faces(sprite):
    faces = {}

    size = sprite.get_size()
    tile_size = (int(size[0] / 1),int(size[1] / 1))

    facedown = pygame.Surface(tile_size,pygame.SRCALPHA)
    facedown.blit(sprite, (0,0))
    faces["facedown"] = facedown

    faceup = pygame.Surface(tile_size, pygame.SRCALPHA)
    faceup.blit(sprite, (0,0))
    faces["faceup"] = faceup

    faceleft = pygame.Surface(tile_size,pygame.SRCALPHA)
    faceleft.blit(sprite, (0,0))
    faces["faceleft"] = faceleft

    faceright = pygame.Surface(tile_size, pygame.SRCALPHA)
    faceright.blit(sprite, (0,0))
    faces["faceright"] = faceright

    return faces




class Monster:

    allMonster = []

    def __init__(self, name,pos,hp,attack,xp,lvl,sprite):
        self.name = name
        self.x = pos[0]
        self.y = pos[1]
        self.maxhp = hp
        self.hp = self.maxhp
        self.attack = attack
        self.maxxp = xp
        self.lvl = lvl
        self.maxlvl = 10

        self.width = sprite.get_width()
        self.height = sprite.get_height()
        self.walking = False
        self.Timer = Timer(1)
        self.Timer.OnNext = lambda: MoveNPC(self)
        self.Timer.Start()

        self.Lastlocation = [0,0]

        #Get NPC face
        self.facing = "facedown"
        self.faces = get_faces(sprite)

        #PUBLISH
        Monster.allMonster.append(self)

    def Render(self, surface):
        self.Timer.Update()
        if self.walking:
            move_speed = 100 * Global.deltatime
            if self.facing == "facedown":
                self.y += move_speed
            elif self.facing == "faceup":
                self.y -= move_speed
            elif self.facing == "faceright":
                self.x += move_speed
            elif self.facing == "faceleft":
                self.x -= move_speed

            location = [round(self.x / Tiles.size), round(self.y / Tiles.size)]
            if self.Lastlocation in Tiles.Blocked:
                Tiles.Blocked.remove(self.Lastlocation)

            if not location in Tiles.Blocked:
                Tiles.Blocked.append(location)
                self.Lastlocation = location


        surface.blit(self.faces[self.facing], (self.x + Global.camera_x, self.y + Global.camera_y))

#MONSTER PIC
slimepic = pygame.image.load("tiles\\slime1.gif")
slimepic = pygame.transform.scale(slimepic,(32,32))

snakepic = pygame.image.load("tiles\\snake.png")
snakepic = pygame.transform.scale(snakepic,(32,32))

# fishmanpic = pygame.image.load("tiles\\")


littledragon = pygame.image.load("tiles\\littledragonsprite.png")
littledragon = pygame.transform.scale(littledragon, (80,80))


bigdragon = pygame.image.load("tiles\\bigdragonsprite.gif")
bigdragon = pygame.transform.scale(bigdragon, (128,128))


class Slime(Monster):

    def __init__(self, name, pos, hp, attack, xp ,lvl):
        super().__init__(name, pos,hp,attack,xp,lvl,(slimepic))

class Snake(Monster):

    def __init__(self, name, pos, hp, attack, xp ,lvl):
        super().__init__(name, pos, hp ,attack, xp, lvl,(snakepic))

class Fishman(Monster):
    def __init__(self, name, pos, hp, attack, xp ,lvl):
        super().__init__(name, pos, hp, attack, xp, lvl,(None))

class Littledragon(Monster):
    def __init__(self, name, pos, hp, attack, xp ,lvl):
        super().__init__(name, pos, hp, attack, xp, lvl,(littledragon))

class Bigdragon(Monster):

    def __init__(self, name, pos, hp, attack, xp ,lvl):
        super().__init__(name, pos, hp, attack, xp, lvl,(bigdragon))




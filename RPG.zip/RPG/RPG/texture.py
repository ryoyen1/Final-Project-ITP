import pygame

pygame.init()


class Tiles:
    size = 32

    Blocked = []

    Blocked_types = ["2","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","29","30","31"]
    def blockedAt(pos):
        if list(pos) in Tiles.Blocked:
            return True
        else:
            return False

    def Texture(file, size):
        bitmap = pygame.image.load(file)
        bitmap = pygame.transform.scale(bitmap,(size,size))
        surface = pygame.Surface((size,size))
        surface.blit(bitmap, (0,0))
        return surface

    Grass = Texture("tiles\\grass.png", size)
    Blockedgrass = Texture("tiles\\grass2.png",size)
    Tree = Texture("tiles\\tree.png", size)
    Wood = Texture("tiles\\wood.png", size)
    Stone = Texture("tiles\\stone.png", size)
    Rose = Texture("tiles\\rose.png", size)
    Fence = Texture("tiles\\fence.png", size)
    Wall = Texture("tiles\\wall.png", size)
    roof_mid = Texture("tiles\\roof_mid.png", size)
    roof_nmid = Texture("tiles\\roof_nmid.png", size)
    roof_w = Texture("tiles\\roof_w.png", size)
    roof_sw = Texture("tiles\\roof_sw.png", size)
    roof_smid = Texture("tiles\\roof_smid.png", size)
    roof_se = Texture("tiles\\roof_se.png", size)
    sign_weapon = Texture("tiles\\sign_weapon.png", size)
    wall_bot_e = Texture("tiles\\wall_bot_e.png", size)
    wall_door = Texture("tiles\\wall_door.png", size)
    wall_se = Texture("tiles\\wall_se.png", size)
    window = Texture("tiles\\window.png", size)
    roof_nw = Texture("tiles\\roof_nw.png", size)
    roof_ne = Texture("tiles\\roof_ne.png", size)
    wallarmor = Texture("tiles\\wall_suit_of_armor.png", size)
    water = Texture("tiles\\water\\water.png", size)
    bridge = Texture("tiles\\water\\bridge.png", size)
    bridge_cross = Texture("tiles\\water\\bridge_cross.png", size)
    bridge_e = Texture("tiles\\water\\bridge_e.png", size)
    bridge_n = Texture("tiles\\water\\bridge_n.png", size)
    bridge_w = Texture("tiles\\water\\bridge_w.png", size)
    bridge_s = Texture("tiles\\water\\bridge_s.png", size)
    bridge_ns_destroyed = Texture("tiles\\water\\bridge_ns_destroyed.png", size)
    lava = Texture("tiles\\lava.png",size)

    Texture_ID = {"1" : Grass,
                  "2" : Tree,
                  "3" : Wood,
                  "4" : Stone,
                  "5" : Rose,
                  "6" : Fence,
                  "7" : Wall,
                  "8" : roof_mid,
                  "9" : roof_nmid,
                  "10" : roof_w,
                  "11" : roof_sw,
                  "12" : roof_smid,
                  "13" : roof_se,
                  "14" : sign_weapon,
                  "15" : wall_bot_e,
                  "16" : wall_door,
                  "17" : wall_se,
                  "18" : window,
                  "19" : roof_nw,
                  "20" : roof_ne,
                  "21" : wallarmor,
                  "22" : water,
                  "23" : bridge,
                  "24" : bridge_cross,
                  "25" : bridge_e,
                  "26" : bridge_n,
                  "27" : bridge_w,
                  "28" : bridge_s,
                  "29" : bridge_ns_destroyed,
                  "30" : Blockedgrass,
                  "31" : lava}


import pygame, random
from timer import *
from globals import *
from texture import *

pygame.init()

def get_faces(sprite):
    faces = {}

    size = sprite.get_size()
    tile_size = (int(size[0] / 2),int(size[1] / 2))

    facedown = pygame.Surface(tile_size,pygame.SRCALPHA)
    facedown.blit(sprite, (0,0), (0,0 , tile_size[0], tile_size[1]))
    faces["facedown"] = facedown

    faceup = pygame.Surface(tile_size, pygame.SRCALPHA)
    faceup.blit(sprite, (0,0), (tile_size[0], tile_size[1], tile_size[0], tile_size[1]))
    faces["faceup"] = faceup

    faceleft = pygame.Surface(tile_size,pygame.SRCALPHA)
    faceleft.blit(sprite, (0,0), (tile_size[0], 0 , tile_size[0], tile_size[1]))
    faces["faceleft"] = faceleft

    faceright = pygame.Surface(tile_size, pygame.SRCALPHA)
    faceright.blit(sprite, (0,0), (0,tile_size[1], tile_size[0],tile_size[1]))
    faces["faceright"] = faceright

    return faces

def MoveNPC(npc):
    npc.facing = random.choice(("faceup","facedown","faceleft","faceright"))
    npc.walking = random.choice((True,False))

class Dialog:

    def __init__(self,text):
        self.Page = 0
        self.Text = text    #[("Hello friend!", "Can you help me with this delivery?")]


class NPC:

    allNPC = []

    def __init__(self, name, pos, dialog, sprite):
        self.name = name
        self.x = pos[0]
        self.y = pos[1]
        self.Dialog = dialog
        self.width = sprite.get_width()
        self.height = sprite.get_height()
        self.walking = False
        self.Timer = Timer(1)
        self.Timer.OnNext = lambda: MoveNPC(self)
        self.Timer.Start()

        self.Lastlocation = [0,0]

        #Get NPC face
        self.facing = "faceup"
        self.faces = get_faces(sprite)

        #PUBLISH
        NPC.allNPC.append(self)

    def Render(self, surface):
        self.Timer.Update()
        if self.walking:
            move_speed = 100 * Global.deltatime
            if self.facing == "facedown":
                self.y += move_speed
            elif self.facing == "faceup":
                self.y -= move_speed
            elif self.facing == "faceright":
                self.x += move_speed
            elif self.facing == "faceleft":
                self.x -= move_speed

            location = [round(self.x / Tiles.size), round(self.y / Tiles.size)]
            if self.Lastlocation in Tiles.Blocked:
                Tiles.Blocked.remove(self.Lastlocation)

            if not location in Tiles.Blocked:
                Tiles.Blocked.append(location)
                self.Lastlocation = location


        surface.blit(self.faces[self.facing], (self.x + Global.camera_x, self.y + Global.camera_y))

class Male1(NPC):

    def __init__(self, name, pos, dialog = None):
        super().__init__(name, pos, dialog, pygame.image.load("tiles\\male1.png"))




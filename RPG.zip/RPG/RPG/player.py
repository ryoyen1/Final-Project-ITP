import pygame
from NPC import *

pygame.init()

class Player:

    def __init__(self,name,hp,attack,xp,lv,pot):
        self.name = name
        self.maxhp = hp
        self.hp = self.maxhp
        self.attack = attack
        self.maxxp = xp
        self.xp = 0
        self.lv = lv
        self.maxlv = 11
        self.pot = pot

        self.facing = "facedown"
        sprite = pygame.image.load("tiles\\player\\player.png")



        size = sprite.get_size()
        self.width = size[0]
        self.height = size[1]

        #Model faces
        self.faces = get_faces(sprite)


    def render(self, surface, pos):      #render to a curtain surface
        #self.pos = pos
        #pos = (640 , 320)
        surface.blit(self.faces[self.facing], pos)





#Reference Youtube
import pygame
from texture import *

class Map_engine:
    def add_tile(tile,pos, addTo):
        addTo.blit(tile,(pos[0] * Tiles.size, pos[1] * Tiles.size))

    def load_map(file):
        with open(file, "r") as mapfile:
            map_data = mapfile.read()

        #Read data map
        map_data = map_data.split("-")

        mapsize = map_data[len(map_data) -1 ] #Map dimensions
        map_data.remove(mapsize)
        mapsize = mapsize.split(",")
        mapsize[0] = int(mapsize[0]) * Tiles.size
        mapsize[1] = int(mapsize[1]) * Tiles.size

        tiles = []

        for tile in range(len(map_data)):
            map_data[tile] = map_data[tile].replace("\n","")
            tiles.append(map_data[tile].split(":")) #Split pos from texture

        for tile in tiles:
            tile[0] = tile[0].split(",")
            pos = tile[0]
            for p in pos:
                pos[pos.index(p)] = int(p)

            tiles[tiles.index(tile)] = (pos, tile[1])

        #Create Terrain
        terrain = pygame.Surface(mapsize)

        for tile in tiles:
            if tile[1] in Tiles.Texture_ID:
                Map_engine.add_tile(Tiles.Texture_ID[tile[1]], tile[0], terrain)

            if tile[1] in Tiles.Blocked_types:
                Tiles.Blocked.append(tile[0])

        return terrain
